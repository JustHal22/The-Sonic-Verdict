---
layout: page
title: About
permalink: /about/
---

Welcome to **The Sonic Verdict** — your destination for honest, sharp, and stylish music reviews. Curated by JustHal.